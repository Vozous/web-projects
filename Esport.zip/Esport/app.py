from flask import Flask, render_template,request


app = Flask(__name__)


@app.route('/')
def index():
	txt = "Helo Flasky world !"

	return render_template("index.html", text=txt)


@app.route('/resultat', methods=['POST'])
def resultat():
	result = request.form
	n = result['nom']
	p = result['prenom']

	return render_template("resultat.html", nom=n, prenom=p)


app.run(debug=True)